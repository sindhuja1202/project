
  var firebaseConfig = {
    apiKey: "AIzaSyD5AOkeIUOV-XgLvr48s2Fx7q1BUB9ZUBM",
    authDomain: "customerinterface.firebaseapp.com",
    databaseURL: "https://customerinterface.firebaseio.com",
    projectId: "customerinterface",
    storageBucket: "customerinterface.appspot.com",
    messagingSenderId: "326645201587",
    appId: "1:326645201587:web:d45e51af896c1e59"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);